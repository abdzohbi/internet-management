

<?php $__env->startSection('title', 'Outstanding Customers Report'); ?>

<?php $__env->startSection('content'); ?>
<style>
    @media print {
        body * {
            visibility: hidden;
        }
        .container, .container * {
            visibility: visible;
        }
        .container {
            position: absolute;
            top: 0;
            left: 0;
        }
        .btn {
            display: none;
        }
    }
</style>

<div class="container">
    <h1 class="mb-4">Outstanding Customers Report</h1>

    <!-- زر الطباعة -->
    <div class="mb-3">
        <button class="btn btn-primary" onclick="window.print()">
            <i class="bi bi-printer"></i> Print
        </button>
    </div>
    <a href="<?php echo e(route('reports.export.customers.balance')); ?>" class="btn btn-success">
    <i class="bi bi-file-earmark-excel"></i> Export Customers to Excel
</a>



    <?php if($outstandingCustomers->isEmpty()): ?>
        <div class="alert alert-success">No outstanding bills found.</div>
    <?php else: ?>
    <table class="table table-bordered">
    <thead>
        <tr>
            <th>#</th>
            <th>Full Name</th>
            <th>Username</th>
            <th>Phone</th>
            <th>Town</th>
            <th>Total Subscriptions</th>
            <th>Total Receipts</th>
            <th>Balance</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $outstandingCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $totalSubscriptions = $customer->subscriptions->sum('price');
                $totalReceipts = $customer->receipts->sum('amount');
                $balance = $totalSubscriptions - $totalReceipts;
            ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($customer->full_name); ?></td>
                <td><?php echo e($customer->username); ?></td>
                <td><?php echo e($customer->phone); ?></td>
                <td><?php echo e($customer->town); ?></td>
                <td>$<?php echo e(number_format($totalSubscriptions, 2)); ?></td>
                <td>$<?php echo e(number_format($totalReceipts, 2)); ?></td>
                <td>$<?php echo e(number_format($balance, 2)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\reports\outstanding_customers.blade.php ENDPATH**/ ?>