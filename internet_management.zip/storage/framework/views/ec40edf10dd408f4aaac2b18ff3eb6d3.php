

<?php $__env->startSection('title', 'Add Customer'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Add New Customer</h1>

    <form method="POST" action="<?php echo e(route('customers.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" name="username" id="username" class="form-control" value="<?php echo e(old('username')); ?>" required>
        </div>
        <div class="mb-3">
            <label for="full_name" class="form-label">Full Name</label>
            <input type="text" name="full_name" id="full_name" class="form-control" value="<?php echo e(old('full_name')); ?>" required>
        </div>
        <div class="mb-3">
            <label for="phone" class="form-label">Phone</label>
            <input type="text" name="phone" id="phone" class="form-control" value="<?php echo e(old('phone')); ?>" required>
        </div>
        <div class="mb-3">
            <label for="town" class="form-label">Town</label>
            <input type="text" name="town" id="town" class="form-control" value="<?php echo e(old('town')); ?>">
        </div>
        <div class="mb-3">
            <label for="address" class="form-label">Address</label>
            <textarea name="address" id="address" class="form-control"><?php echo e(old('address')); ?></textarea>
        </div>
        <div class="mb-3">
    <label for="connection_point_id" class="form-label">Connection Point</label>
    <select name="connection_point_id" id="connection_point_id" class="form-select">
        <option value="">Select a Connection Point</option>
        <?php $__currentLoopData = $connectionPoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($point->id); ?>"><?php echo e($point->name); ?> (<?php echo e($point->station); ?>)</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
        <button type="submit" class="btn btn-primary">Add Customer</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\customers\create.blade.php ENDPATH**/ ?>