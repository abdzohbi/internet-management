

<?php $__env->startSection('title', 'Add New Tag'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Add New Tag</h1>
    <form method="POST" action="<?php echo e(route('tags.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Tag Name</label>
            <input type="text" name="name" id="name" class="form-control" placeholder="Enter tag name" required>
        </div>
        <button type="submit" class="btn btn-primary">Add Tag</button>
        <a href="<?php echo e(route('expenses.index')); ?>" class="btn btn-secondary">Back to Expenses</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\tags\create.blade.php ENDPATH**/ ?>