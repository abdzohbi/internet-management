

<?php $__env->startSection('title', 'Expenses List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- العنوان وزر إضافة المصروف -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3"><i class="bi bi-wallet2"></i> Expenses List</h1>
        <a href="<?php echo e(route('expenses.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg"></i> Add Expense
        </a>
        <a href="<?php echo e(route('tags.index')); ?>" class="btn btn-info">
            <i class="bi bi-tags"></i> Manage Tags
        </a>
    </div>

    <!-- إشعارات النجاح -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <form method="GET" action="<?php echo e(route('expenses.index')); ?>" class="mb-4">
    <div class="row g-3 align-items-center">
        <!-- البحث -->
        <div class="col-md-4">
            <input type="text" name="search" id="search" class="form-control"
                   placeholder="Search by type or description" value="<?php echo e(request('search')); ?>">
        </div>

        <!-- الفلترة بالتواريخ -->
        <div class="col-md-3">
            <input type="date" name="start_date" id="start_date" class="form-control"
                   value="<?php echo e(request('start_date')); ?>">
        </div>
        <div class="col-md-3">
            <input type="date" name="end_date" id="end_date" class="form-control"
                   value="<?php echo e(request('end_date')); ?>">
        </div>

        <!-- الفلترة حسب التاغات -->
        <div class="col-md-4">
            <select name="tags[]" id="tags" class="form-select" multiple>
                <?php $__currentLoopData = $availableTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($tag->id); ?>" 
                        <?php echo e(request('tags') && in_array($tag->id, request('tags')) ? 'selected' : ''); ?>>
                        <?php echo e($tag->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- أزرار البحث -->
        <div class="col-md-2 d-flex gap-2">
            <button type="submit" class="btn btn-primary w-100">Filter</button>
            <a href="<?php echo e(route('expenses.index')); ?>" class="btn btn-secondary w-100">Reset</a>
        </div>
    </div>
</form>



    <!-- جدول المصاريف -->
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Tags</th>
                <th>Type</th>
                <th>Description</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>
                        <?php if($expense->tags && $expense->tags->isNotEmpty()): ?>
                            <?php $__currentLoopData = $expense->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-secondary"><?php echo e($tag->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <span class="text-muted">No Tags</span>
                        <?php endif; ?>
                    </td>

                    <td><?php echo e($expense->type); ?></td>
                    <td><?php echo e($expense->description); ?></td>
                    <td>$<?php echo e(number_format($expense->amount, 2)); ?></td>
                    <td><?php echo e($expense->date); ?></td>
                    <td>
                        <a href="<?php echo e(route('expenses.edit', $expense->id)); ?>" class="btn btn-warning btn-sm">
                            <i class="bi bi-pencil"></i> Edit
                        </a>
                        <form action="<?php echo e(route('expenses.destroy', $expense->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">
                                <i class="bi bi-trash"></i> Delete
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center">No expenses found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- التصفح -->
    <div class="d-flex justify-content-center mt-4">
        <?php echo e($expenses->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\expenses\index.blade.php ENDPATH**/ ?>