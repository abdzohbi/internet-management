

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="card text-white bg-primary">
                <div class="card-body">
                    <h5 class="card-title">Total Customers</h5>
                    <p class="card-text display-6"><?php echo e($totalCustomers); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-success">
                <div class="card-body">
                    <h5 class="card-title">Expenses This Month</h5>
                    <p class="card-text display-6">$<?php echo e(number_format($totalExpensesThisMonth, 2)); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-danger">
                <div class="card-body">
                    <h5 class="card-title">Outstanding Balances</h5>
                    <p class="card-text display-6">$<?php echo e(number_format($outstandingBalances, 2)); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-info">
                <div class="card-body">
                    <h5 class="card-title">Subscriptions This Month</h5>
                    <p class="card-text display-6"><?php echo e($totalSubscriptionsCount); ?> / $<?php echo e(number_format($totalSubscriptionsValue, 2)); ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="mt-4">
        <h4>Subscriptions Per Company</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Company</th>
                    <th>Count</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $subscriptionsPerCompany; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($company); ?></td>
                    <td><?php echo e($data['count']); ?></td>
                    <td>$<?php echo e(number_format($data['total'], 2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\dashboard\index.blade.php ENDPATH**/ ?>