

<?php $__env->startSection('title', 'Packages'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Packages</h1>
    <a href="<?php echo e(route('packages.create')); ?>" class="btn btn-primary mb-3">Add Package</a>
    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Company</th>
                <th>Package Name</th>
                <th>Purchase Price</th>
                <th>Sale Price</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($package->company->name); ?></td>
                    <td><?php echo e($package->name); ?></td>
                    <td>$<?php echo e($package->purchase_price); ?></td>
                    <td>$<?php echo e($package->sale_price); ?></td>
                    <td>
                        <a href="<?php echo e(route('packages.edit', $package->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('packages.destroy', $package->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\packages\index.blade.php ENDPATH**/ ?>