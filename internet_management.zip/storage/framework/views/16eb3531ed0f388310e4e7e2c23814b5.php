

<?php $__env->startSection('title', 'Create Maintenance Log'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Create Maintenance Log</h1>
    <form action="<?php echo e(route('maintenance_logs.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
    <label for="customer_id" class="form-label">Customer</label>
    <select name="customer_id" id="customer_id" class="form-control" required>
        <option value="" disabled selected>Select a customer</option>
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->full_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>


        <div class="mb-3">
            <label for="maintenance_date" class="form-label">Maintenance Date</label>
            <input type="date" name="maintenance_date" id="maintenance_date" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="notes" class="form-label">Notes</label>
            <textarea name="notes" id="notes" class="form-control"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\maintenance_logs\create.blade.php ENDPATH**/ ?>