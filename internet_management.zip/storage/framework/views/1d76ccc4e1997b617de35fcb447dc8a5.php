

<?php $__env->startSection('title', "Maintenance Logs for $customer->full_name"); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Maintenance Logs for <?php echo e($customer->full_name); ?> (<?php echo e($customer->username); ?>)</h1>
    <a href="<?php echo e(route('maintenance_logs.index')); ?>" class="btn btn-secondary mb-3">Back to All Logs</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Date</th>
                <th>Notes</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($log->id); ?></td>
                <td><?php echo e($log->maintenance_date); ?></td>
                <td><?php echo e($log->notes); ?></td>
                <td>
                    <a href="<?php echo e(route('maintenance_logs.edit', $log->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('maintenance_logs.destroy', $log->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\maintenance_logs\by_customer.blade.php ENDPATH**/ ?>