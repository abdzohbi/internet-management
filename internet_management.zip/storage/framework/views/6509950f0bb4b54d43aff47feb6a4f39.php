

<?php $__env->startSection('title', 'Customer Report'); ?>

<?php $__env->startSection('content'); ?>

<style>
    @media print {

        @page {
            margin: 20mm;
        }

        /* إخفاء العناصر الإضافية */
        body {
            margin: 0;
            padding: 0;
        }

        /* إخفاء أي أزرار أو عناصر غير التقرير */
        button, .navbar, footer, .d-print-none {
            display: none !important;
        }
        /* إزالة العناصر غير الضرورية */
        body * {
            visibility: hidden;
        }

        #print-area, #print-area * {
            visibility: visible;
        }

        #print-area {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
        }

        /* تقليل حجم النص لتحسين التناسب */
        body {
            font-size: 12px;
        }

        h1, h4 {
            text-align: center;
            margin-bottom: 10px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            font-size: 12px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 5px;
        }

        th {
            background-color: #f2f2f2;
            text-align: left;
        }

        /* إزالة زر الطباعة */
        .d-print-none {
            display: none !important;
        }

        /* تخصيص المساحة للطباعة */
        @page {
            size: A4;
            margin: 20mm;
        }
    }
</style>

<div class="container" id="print-area">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="text-center w-100">Customer Report</h1>
        <button onclick="window.print()" class="btn btn-primary d-print-none">Print</button>
    </div>

    <!-- معلومات العميل -->
    <div class="mb-4">
        <p><strong>Full Name:</strong> <?php echo e($customer->full_name); ?></p>
        <p><strong>Username:</strong> <?php echo e($customer->username); ?></p>
        <p><strong>Phone:</strong> <?php echo e($customer->phone); ?></p>
        <p><strong>Town:</strong> <?php echo e($customer->town); ?></p>
    </div>

    <!-- جدول الاشتراكات -->
    <div class="mb-4">
        <h4>Subscriptions</h4>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Package</th>
                    <th>Price</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $customer->subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($subscription->package_name); ?></td>
                        <td>$<?php echo e($subscription->price); ?></td>
                        <td><?php echo e($subscription->start_date); ?></td>
                        <td><?php echo e($subscription->end_date); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- جدول الدفعات -->
    <div class="mb-4">
        <h4>Receipts</h4>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Amount</th>
                    <th>Description</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $customer->receipts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receipt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td>$<?php echo e($receipt->amount); ?></td>
                        <td><?php echo e($receipt->description); ?></td>
                        <td><?php echo e($receipt->date); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- ملخص القيم التراكمية -->
    <div>
        <h4>Summary</h4>
        <p><strong>Total Subscriptions:</strong> $<?php echo e($totalSubscriptions); ?></p>
        <p><strong>Total Receipts:</strong> $<?php echo e($totalReceipts); ?></p>
        <p><strong>Balance:</strong> $<?php echo e($balance); ?></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\customers\report.blade.php ENDPATH**/ ?>