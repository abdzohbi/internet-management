

<?php $__env->startSection('title', 'Customer Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Customer Details</h1>

    <div class="mb-3">
        <label class="form-label">Full Name:</label>
        <p><?php echo e($customer->full_name); ?></p>
    </div>
    <div class="mb-3">
        <label class="form-label">Phone:</label>
        <p><?php echo e($customer->phone); ?></p>
    </div>
    <div class="mb-3">
        <label class="form-label">Town:</label>
        <p><?php echo e($customer->town); ?></p>
    </div>
    <div class="mb-3">
        <label class="form-label">Address:</label>
        <p><?php echo e($customer->address); ?></p>
    </div>
    <div class="mb-3">
        <label class="form-label">Point:</label>
        <p><?php echo e($customer->connectionPoint->name ?? 'N/A'); ?></p>
    </div>

    <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-secondary">Back to List</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\customers\show.blade.php ENDPATH**/ ?>