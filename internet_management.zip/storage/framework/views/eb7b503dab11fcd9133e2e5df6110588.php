

<?php $__env->startSection('title', 'Financial Report'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4"><i class="bi bi-file-earmark-text"></i> Financial Report</h1>
    <h5 class="text-muted">Report from <?php echo e($start_date); ?> to <?php echo e($end_date); ?></h5>

    <div class="row my-4">
        <div class="col-md-4">
            <h3>Total Expenses</h3>
            <p class="fs-4 text-danger">$<?php echo e(number_format($totalExpenses, 2)); ?></p>
        </div>
        <div class="col-md-4">
            <h3>Total Subscriptions</h3>
            <p class="fs-4 text-success">$<?php echo e(number_format($totalIncome, 2)); ?></p>
        </div>
        <div class="col-md-4">
            <h3>Total Debts</h3>
            <p class="fs-4 text-warning">$<?php echo e(number_format($totalDebts, 2)); ?></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\reports\financial.blade.php ENDPATH**/ ?>