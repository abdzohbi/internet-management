

<?php $__env->startSection('title', 'Maintenance Logs'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Maintenance Logs</h1>
    <a href="<?php echo e(route('maintenance_logs.create')); ?>" class="btn btn-primary mb-3">Add New Log</a>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <div class="mb-3">
    <form action="<?php echo e(route('maintenance_logs.index')); ?>" method="GET">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by Username or Name" value="<?php echo e(request('search')); ?>">
            <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </form>
</div>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>UserName</th>
                <th>Name</th>
                <th>Date</th>
                <th>Notes</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($log->id); ?></td>
                <td><a href="<?php echo e(route('maintenance_logs.by_customer', $log->customer->id)); ?>"><?php echo e($log->customer->username); ?></a></td>
                <td><?php echo e($log->customer->full_name); ?></td>
                <td><?php echo e($log->maintenance_date); ?></td>
                <td><?php echo e($log->notes); ?></td>
                <td>
                    <a href="<?php echo e(route('maintenance_logs.edit', $log->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('maintenance_logs.destroy', $log->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\maintenance_logs\index.blade.php ENDPATH**/ ?>