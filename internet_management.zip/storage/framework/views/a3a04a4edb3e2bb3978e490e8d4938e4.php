

<?php $__env->startSection('title', 'Subscriptions'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Subscriptions</h1>
    
    <a href="<?php echo e(route('subscriptions.create')); ?>" class="btn btn-primary">
            <i class="fa fa-plus"></i> Add New Receipt
        </a>
    <!-- نموذج البحث والفلترة -->
    <form method="GET" action="<?php echo e(route('subscriptions.index')); ?>" class="mb-4">
        <div class="row">
            <div class="col-md-3">
                <input type="text" name="search" id="search" class="form-control" 
                       placeholder="Search by username or customer name" value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-3">
                <input type="date" name="start_date" id="start_date" class="form-control" 
                       value="<?php echo e(request('start_date')); ?>" placeholder="Start Date">
            </div>
            <div class="col-md-3">
                <input type="date" name="end_date" id="end_date" class="form-control" 
                       value="<?php echo e(request('end_date')); ?>" placeholder="End Date">
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
            </div>
        </div>
    </form>

    <!-- جدول الاشتراكات -->
    <table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>#</th>
            <th>Username</th>
            <th>Customer Name</th>
            <th>Package</th>
            <th>Price</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td>
                    <a href="<?php echo e(route('customers.report', $subscription->customer->id)); ?>" class="text-decoration-none">
                        <?php echo e($subscription->customer->username); ?>

                    </a>
                </td>
                <td><?php echo e($subscription->customer->full_name); ?></td>
                <td><?php echo e($subscription->package_name); ?></td>
                <td>$<?php echo e($subscription->price); ?></td>
                <td><?php echo e($subscription->start_date); ?></td>
                <td><?php echo e($subscription->end_date); ?></td>
                <td>
                    <a href="<?php echo e(route('subscriptions.edit', $subscription->id)); ?>" class="btn btn-sm btn-warning">
                        <i class="fa fa-edit"></i> Edit
                    </a>
                    <form action="<?php echo e(route('subscriptions.destroy', $subscription->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                            <i class="fa fa-trash"></i> Delete
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

    <!-- التصفح -->
    <div class="d-flex justify-content-center">
        <?php echo e($subscriptions->withQueryString()->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\subscriptions\index.blade.php ENDPATH**/ ?>