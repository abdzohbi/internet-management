

<?php $__env->startSection('title', 'Tags Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4"><i class="bi bi-tags"></i> Tags Management</h1>

    <!-- إشعارات النجاح أو الخطأ -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- نموذج إضافة تاغ جديد -->
    <form method="POST" action="<?php echo e(route('tags.store')); ?>" class="mb-4">
        <?php echo csrf_field(); ?>
        <div class="input-group">
            <input type="text" name="name" class="form-control" placeholder="Enter tag name" required>
            <button type="submit" class="btn btn-primary">Add Tag</button>
        </div>
    </form>

    <!-- جدول عرض التاغات -->
    <?php if($tags->isNotEmpty()): ?>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($tag->name); ?></td>
                        <td>
                            <form action="<?php echo e(route('tags.destroy', $tag->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <!-- التحقق من إمكانية الحذف -->
                                <?php if($tag->expenses->isEmpty()): ?>
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">
                                        <i class="bi bi-trash"></i> Delete
                                    </button>
                                <?php else: ?>
                                    <button type="button" class="btn btn-secondary btn-sm" disabled>
                                        <i class="bi bi-lock"></i> Used
                                    </button>
                                <?php endif; ?>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-center text-muted">No tags found. Start adding some!</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\tags\index.blade.php ENDPATH**/ ?>