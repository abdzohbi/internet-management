

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Import Previous Backup</h1>
    <form action="#" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="backupFile" class="form-label">Select Backup File</label>
            <input type="file" class="form-control" id="backupFile" name="backup_file" required>
        </div>
        <button type="submit" class="btn btn-primary">Import</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\backup\import.blade.php ENDPATH**/ ?>