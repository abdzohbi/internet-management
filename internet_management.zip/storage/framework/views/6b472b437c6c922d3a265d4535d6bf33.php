

<?php $__env->startSection('title', 'Edit Maintenance Log'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Maintenance Log</h1>
    <form action="<?php echo e(route('maintenance_logs.update', $maintenanceLog->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="customer_id" class="form-label">Customer</label>
            <select name="customer_id" id="customer_id" class="form-control" required>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($customer->id); ?>" <?php echo e($customer->id == $maintenanceLog->customer_id ? 'selected' : ''); ?>>
                        <?php echo e($customer->full_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="maintenance_date" class="form-label">Maintenance Date</label>
            <input type="date" name="maintenance_date" id="maintenance_date" class="form-control" value="<?php echo e($maintenanceLog->maintenance_date); ?>" required>
        </div>
        <div class="mb-3">
            <label for="notes" class="form-label">Notes</label>
            <textarea name="notes" id="notes" class="form-control"><?php echo e($maintenanceLog->notes); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Save Changes</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\maintenance_logs\edit.blade.php ENDPATH**/ ?>