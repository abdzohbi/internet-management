

<?php $__env->startSection('title', 'Edit Connection Point'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Connection Point</h1>
    <form action="<?php echo e(route('connection_points.update', $connectionPoint->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input type="text" name="name" id="name" class="form-control" value="<?php echo e($connectionPoint->name); ?>" required>
        </div>
        <div class="mb-3">
            <label for="station" class="form-label">Station</label>
            <input type="text" name="station" id="station" class="form-control" value="<?php echo e($connectionPoint->station); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="<?php echo e(route('connection_points.index')); ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\connection_points\edit.blade.php ENDPATH**/ ?>