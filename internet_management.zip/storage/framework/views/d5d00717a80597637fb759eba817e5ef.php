

<?php $__env->startSection('title', 'Edit Customer'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Customer</h1>

    <form method="POST" action="<?php echo e(route('customers.update', $customer->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" name="username" id="username" class="form-control" value="<?php echo e(old('username', $customer->username)); ?>" required>
        </div>
        <div class="mb-3">
            <label for="full_name" class="form-label">Full Name</label>
            <input type="text" name="full_name" id="full_name" class="form-control" value="<?php echo e(old('full_name', $customer->full_name)); ?>" required>
        </div>
        <div class="mb-3">
            <label for="phone" class="form-label">Phone</label>
            <input type="text" name="phone" id="phone" class="form-control" value="<?php echo e(old('phone', $customer->phone)); ?>" required>
        </div>
        <div class="mb-3">
            <label for="town" class="form-label">Town</label>
            <input type="text" name="town" id="town" class="form-control" value="<?php echo e(old('town', $customer->town)); ?>">
        </div>
        <div class="mb-3">
            <label for="address" class="form-label">Address</label>
            <textarea name="address" id="address" class="form-control"><?php echo e(old('address', $customer->address)); ?></textarea>
        </div>
        <div class="mb-3">
            <label for="connection_point_id" class="form-label">Connection Point</label>
            <select name="connection_point_id" id="connection_point_id" class="form-select">
                <option value="">Select a Connection Point</option>
                <?php $__currentLoopData = $connectionPoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($point->id); ?>" <?php echo e($customer->connection_point_id == $point->id ? 'selected' : ''); ?>>
                        <?php echo e($point->name); ?> (<?php echo e($point->station); ?>)
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
</div>
        <button type="submit" class="btn btn-primary">Update Customer</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\customers\edit.blade.php ENDPATH**/ ?>