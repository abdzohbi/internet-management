

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>إدارة معلومات الشركة</h1>
    <form action="<?php echo e(route('company-info.update')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="name" class="form-label">اسم الشركة</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($info->name ?? ''); ?>">
        </div>

        <div class="mb-3">
            <label for="report_name" class="form-label">الاسم في التقارير</label>
            <input type="text" name="report_name" class="form-control" value="<?php echo e($info->report_name ?? ''); ?>">
        </div>

        <div class="mb-3">
            <label for="logo" class="form-label">شعار الشركة</label>
            <input type="file" name="logo" class="form-control">
            <?php if($info && $info->logo): ?>
                <img src="<?php echo e(asset('storage/' . $info->logo)); ?>" alt="الشعار" width="100">
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label for="address" class="form-label">العنوان</label>
            <input type="text" name="address" class="form-control" value="<?php echo e($info->address ?? ''); ?>">
        </div>

        <div class="mb-3">
            <label for="phone" class="form-label">الهاتف</label>
            <input type="text" name="phone" class="form-control" value="<?php echo e($info->phone ?? ''); ?>">
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">البريد الإلكتروني</label>
            <input type="email" name="email" class="form-control" value="<?php echo e($info->email ?? ''); ?>">
        </div>

        <button type="submit" class="btn btn-primary">حفظ</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\company_info\index.blade.php ENDPATH**/ ?>