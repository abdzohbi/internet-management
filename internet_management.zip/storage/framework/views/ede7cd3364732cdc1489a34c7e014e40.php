

<?php $__env->startSection('title', 'Receipts List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4 text-center">Receipts List</h1>

    <!-- أزرار إضافية -->
    <div class="mb-3 d-flex justify-content-between align-items-center">
        <a href="<?php echo e(route('receipts.create')); ?>" class="btn btn-primary">
            <i class="fa fa-plus"></i> Add New Receipt
        </a>
        <div>
            <button  id="printButton" class="btn btn-success me-2">
                <i class="fa fa-print"></i> Print
            </button>
            <a href="<?php echo e(route('reports.export.receipts')); ?>" class="btn btn-info">
                <i class="fa fa-file-excel"></i> Export to Excel
            </a>
        </div>
    </div>

    <!-- نموذج البحث والفلترة -->
    <form method="GET" action="<?php echo e(route('receipts.index')); ?>" class="mb-4">
        <div class="row g-3 align-items-center">
            <div class="col-md-3">
                <input type="text" name="search" id="search" class="form-control" 
                       placeholder="Search by name or username" value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-3">
                <input type="date" name="start_date" id="start_date" class="form-control" 
                       value="<?php echo e(request('start_date')); ?>" placeholder="Start Date">
            </div>
            <div class="col-md-3">
                <input type="date" name="end_date" id="end_date" class="form-control" 
                       value="<?php echo e(request('end_date')); ?>" placeholder="End Date">
            </div>
            <div class="col-md-3 d-flex justify-content-between">
                <button type="submit" class="btn btn-primary w-100 me-2"><i class="fa fa-filter"></i> Filter</button>
                <a href="<?php echo e(route('receipts.index')); ?>" class="btn btn-secondary"><i class="fa fa-sync"></i> Reset</a>
            </div>
        </div>
    </form>

    <!-- جدول الدفعات -->
    <div class="table-responsive">
        <table id="receiptsTable" class="table table-bordered table-hover text-center">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Customer</th>
                    <th>Username</th>
                    <th>Amount</th>
                    <th>Description</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $receipts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receipt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td>
                            <a href="<?php echo e(route('customers.report', $receipt->customer->id)); ?>" class="text-primary">
                                <?php echo e($receipt->customer->full_name); ?>

                            </a>
                        </td>
                        <td><?php echo e($receipt->customer->username); ?></td>
                        <td>$<?php echo e(number_format($receipt->amount, 2)); ?></td>
                        <td><?php echo e($receipt->description); ?></td>
                        <td><?php echo e($receipt->date); ?></td>
                        <td>
                            <a href="<?php echo e(route('receipts.edit', $receipt->id)); ?>" class="btn btn-warning btn-sm">
                                <i class="fa fa-edit"></i> Edit
                            </a>
                            <a href="<?php echo e(route('receipt.print', $receipt->id)); ?>" class="btn btn-warning btn-sm">
                                <i class="fa fa-print"></i> Print
                            </a>


                            <form action="<?php echo e(route('receipts.destroy', $receipt->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">
                                    <i class="fa fa-trash"></i> Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-danger">No receipts found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- مجموع الدفعات -->
    <div class="alert alert-info text-end">
        <strong>Total Receipts: $<?php echo e(number_format($totalReceipts, 2)); ?></strong>
    </div>

    <!-- التصفح -->
    <div class="d-flex justify-content-center">
        <?php echo e($receipts->withQueryString()->links()); ?>

    </div>
</div>

<script>
    document.getElementById('printButton').addEventListener('click', function () {
        // جلب محتوى الجدول
        const tableContent = document.getElementById('receiptsTable').outerHTML;

        // فتح نافذة جديدة
        const printWindow = window.open('', '', 'height=600,width=800');

        // إضافة محتوى الجدول فقط
        printWindow.document.write('<html><head><title>Print Receipts</title></head><body>');
        printWindow.document.write('<table border="1" style="width: 100%; border-collapse: collapse;">');
        printWindow.document.write(tableContent);
        printWindow.document.write('</table>');
        printWindow.document.write('</body></html>');

        // إغلاق نافذة التحرير وتشغيل الطباعة
        printWindow.document.close();
        printWindow.print();
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\receipts\index.blade.php ENDPATH**/ ?>