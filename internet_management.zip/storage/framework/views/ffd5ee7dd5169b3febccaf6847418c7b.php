

<?php $__env->startSection('title', 'Company List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Company List</h1>
    <a href="<?php echo e(route('companies.create')); ?>" class="btn btn-primary mb-3">Add Company</a>

    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($company->name); ?></td>
                    <td><?php echo e($company->address); ?></td>
                    <td><?php echo e($company->phone); ?></td>
                    <td><?php echo e($company->email); ?></td>
                    <td>
                        <a href="<?php echo e(route('companies.edit', $company->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('companies.destroy', $company->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\companies\index.blade.php ENDPATH**/ ?>