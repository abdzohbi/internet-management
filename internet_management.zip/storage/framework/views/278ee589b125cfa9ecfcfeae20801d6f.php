

<?php $__env->startSection('title', 'Customer List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Header Section -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="text-primary">Customer List</h1>
        <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-primary">
            <i class="bi bi-person-plus"></i> Add Customer
        </a>
    </div>

    <!-- Search and Filters -->
    <form method="GET" action="<?php echo e(route('customers.index')); ?>" class="mb-4">
        <div class="row g-2">
            <div class="col-md-4">
                <input type="text" name="search" id="search" class="form-control" placeholder="Search by name or town" autocomplete="off" value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-4">
                <select name="sort_by" class="form-select">
                    <option value="full_name" <?php echo e(request('sort_by') == 'name' ? 'selected' : ''); ?>>Sort by Name</option>
                    <option value="town" <?php echo e(request('sort_by') == 'town' ? 'selected' : ''); ?>>Sort by Town</option>
                </select>
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-filter"></i> Filter
                </button>
            </div>
        </div>
    </form>

    <!-- Customer Table -->
    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Username</th>
                    <th>الأسم</th>
                    <th>الهاتف</th>
                    <th>المدينة</th>
                    <th>الرصيد</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td> <a href="<?php echo e(route('customers.report', $customer->id)); ?>">
                                <?php echo e($customer->username); ?>

                            </a></td>
                        <td><?php echo e($customer->full_name); ?></td>
                        <td><?php echo e($customer->phone); ?></td>
                        <td><?php echo e($customer->town); ?></td>
                        <td>$<?php echo e(number_format($customer->balance, 2)); ?></td>
                        <td>
                            <!-- Dropdown for Actions -->
                            <div class="dropdown">
                                <button class="btn btn-primary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton<?php echo e($customer->id); ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                    Actions
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton<?php echo e($customer->id); ?>">
                                    <li>
                                        <a href="<?php echo e(route('subscriptions.create', ['customer_id' => $customer->id])); ?>" class="dropdown-item">
                                            <i class="bi bi-arrow-repeat"></i> Renew
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('receipts.create', ['customer_id' => $customer->id])); ?>" class="dropdown-item">
                                            <i class="bi bi-cash"></i> Payment
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('maintenance_logs.create', ['customer_id' => $customer->id])); ?>" class="dropdown-item">
                                            <i class="bi bi-tools"></i> Maintenance
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('customers.show', $customer->id)); ?>" class="dropdown-item">
                                            <i class="bi bi-info-circle"></i> Details
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('customers.edit', $customer->id)); ?>" class="dropdown-item">
                                            <i class="bi bi-pencil"></i> Edit
                                        </a>
                                    </li>
                                    <li>
                                        <form action="<?php echo e(route('customers.destroy', $customer->id)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="dropdown-item text-danger">
                                                <i class="bi bi-trash"></i> Delete
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Netplus\internet_management\resources\views\customers\index.blade.php ENDPATH**/ ?>