<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\ConnectionPoint;

use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

class CustomerController extends Controller
{
  /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */



    public function index(Request $request)
    {
        // استعلام العملاء مع العلاقات
        $query = Customer::with(['subscriptions', 'receipts']);
    
        // البحث
        if ($request->has('search') && !empty($request->search)) {
            $search = $request->search;
            $query->where('full_name', 'LIKE', "%{$search}%")
                  ->orWhere('username', 'LIKE', "%{$search}%")
                  ->orWhere('phone', 'LIKE', "%{$search}%")
                  ->orWhere('town', 'LIKE', "%{$search}%");
        }
    
        // الترتيب
        $sortBy = $request->input('sort_by', 'full_name'); // الترتيب الافتراضي حسب الاسم الكامل
        $query->orderBy($sortBy);
    
        // تقسيم النتائج إلى صفحات
        $customers = $query->paginate(10);
    
        // حساب الرصيد لكل عميل
        foreach ($customers as $customer) {
            $totalSubscriptions = $customer->subscriptions->sum('price');
            $totalReceipts = $customer->receipts->sum('amount');
            $customer->balance = $totalSubscriptions - $totalReceipts;
        }
    
        return view('customers.index', compact('customers'));
    }
    
    







    public function create()
    {
        
        $connectionPoints = ConnectionPoint::orderBy('station')->get();
        return view('customers.create', compact('connectionPoints'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'username' => 'required|string|unique:customers,username|max:255',
            'full_name' => 'required|string|max:255',
            'phone' => 'required|string|max:20',
            'town' => 'nullable|string|max:255',
            'address' => 'nullable|string',
            'connection_point_id' => 'nullable|exists:connection_points,id',
        ]);
    
        Customer::create($data);
    
        return redirect()->route('customers.index')->with('success', 'Customer added successfully!');
    }

    public function edit(Customer $customer)
    {
        $connectionPoints = ConnectionPoint::orderBy('station')->get();
            
        
        return view('customers.edit', compact('customer', 'connectionPoints'));
    }

    public function update(Request $request, Customer $customer)
    {
        $data = $request->validate([
            'username' => 'required|string|unique:customers,username,' . $customer->id . '|max:255',
            'full_name' => 'required|string|max:255',
            'phone' => 'required|string|max:20',
            'town' => 'nullable|string|max:255',
            'address' => 'nullable|string',
            'connection_point_id' => 'nullable|exists:connection_points,id',
        ]);
    
        $customer->update($data);
    
        return redirect()->route('customers.index')->with('success', 'Customer updated successfully!');
    }
    public function show($id)
    {
        $customer = Customer::with(['subscriptions', 'receipts', 'maintenanceLogs'])->findOrFail($id);
        return view('customers.show', compact('customer'));
    }
    public function destroy(Customer $customer)
    {
        $customer->delete();

        return redirect()->route('customers.index')->with('success', 'Customer deleted successfully!');
    }

    public function report($id)
    {
        $customer = Customer::with(['subscriptions', 'receipts'])->findOrFail($id);
    
        // حساب القيم التراكمية
        $totalSubscriptions = $customer->subscriptions->sum('price');
        $totalReceipts = $customer->receipts->sum('amount');
        $balance = $totalSubscriptions - $totalReceipts;
    
        return view('customers.report', compact('customer', 'totalSubscriptions', 'totalReceipts', 'balance'));
    }

    public function outstandingReport()
{
    $customers = Customer::with(['subscriptions', 'receipts'])->get();

    $outstandingCustomers = $customers->filter(function ($customer) {
        $totalSubscriptions = $customer->subscriptions->sum('price');
        $totalReceipts = $customer->receipts->sum('amount');
        $balance = $totalSubscriptions - $totalReceipts;

        return $balance > 0; // العملاء الذين لديهم رصيد مستحق
    });

    return view('customers.outstanding', compact('outstandingCustomers'));
}

    
    
    
    
    
}
