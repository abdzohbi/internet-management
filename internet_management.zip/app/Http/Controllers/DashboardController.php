<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Expense;
use App\Models\Subscription;
use Carbon\Carbon;

class DashboardController extends Controller
{



 



    public function index()
    {


        $totalCustomers = Customer::count();
        $totalExpensesThisMonth = Expense::whereMonth('date', Carbon::now()->month)
            ->whereYear('date', Carbon::now()->year)
            ->sum('amount');

        $outstandingBalances = Customer::with(['subscriptions', 'receipts'])->get()
            ->map(function ($customer) {
                $totalSubscriptions = $customer->subscriptions->sum('price');
                $totalReceipts = $customer->receipts->sum('amount');
                return $totalSubscriptions - $totalReceipts;
            })
            ->sum();

        $subscriptionsThisMonth = Subscription::whereMonth('start_date', Carbon::now()->month)
            ->whereYear('start_date', Carbon::now()->year)
            ->get();
        $totalSubscriptionsCount = $subscriptionsThisMonth->count();
        $totalSubscriptionsValue = $subscriptionsThisMonth->sum('price');

        $subscriptionsPerCompany = Subscription::with('package.company')
            ->whereMonth('start_date', Carbon::now()->month)
            ->whereYear('start_date', Carbon::now()->year)
            ->get()
            ->groupBy('package.company.name')
            ->map(function ($subscriptions) {
                return [
                    'count' => $subscriptions->count(),
                    'total' => $subscriptions->sum('price'),
                ];
            });

        return view('dashboard.index', compact(
            'totalCustomers',
            'totalExpensesThisMonth',
            'outstandingBalances',
            'totalSubscriptionsCount',
            'totalSubscriptionsValue',
            'subscriptionsPerCompany'
        ));
    }
}
